import { useState, useEffect } from "react";
import { Timer, TrendingUp, Grid3x3, Play, Pause, RotateCcw, Plus, Check } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { format, startOfWeek, endOfWeek, eachDayOfInterval } from "date-fns";
import type { PomodoroSession, KaizenGoal, EisenhowerTask } from "@shared/schema";

export default function Productivity() {
  return (
    <div className="flex flex-col h-full">
      <div className="flex-none border-b bg-background px-6 py-4">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-2xl font-semibold">Productivity Tools</h1>
        </div>
      </div>

      <div className="flex-1 overflow-auto">
        <div className="max-w-7xl mx-auto p-6">
          <Tabs defaultValue="pomodoro" className="w-full">
            <TabsList className="grid w-full max-w-md grid-cols-3 mb-6">
              <TabsTrigger value="pomodoro" data-testid="tab-pomodoro">
                <Timer className="h-4 w-4 mr-2" />
                Pomodoro
              </TabsTrigger>
              <TabsTrigger value="kaizen" data-testid="tab-kaizen">
                <TrendingUp className="h-4 w-4 mr-2" />
                Kaizen
              </TabsTrigger>
              <TabsTrigger value="eisenhower" data-testid="tab-eisenhower">
                <Grid3x3 className="h-4 w-4 mr-2" />
                Eisenhower
              </TabsTrigger>
            </TabsList>

            <TabsContent value="pomodoro">
              <PomodoroTimer />
            </TabsContent>

            <TabsContent value="kaizen">
              <KaizenTracker />
            </TabsContent>

            <TabsContent value="eisenhower">
              <EisenhowerMatrix />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}

function PomodoroTimer() {
  const [time, setTime] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [mode, setMode] = useState<"focus" | "break">("focus");
  const { toast } = useToast();

  const { data: sessions = [] } = useQuery<PomodoroSession[]>({
    queryKey: ["/api/pomodoro/sessions"],
  });

  const saveMutation = useMutation({
    mutationFn: async (data: { duration: number; type: string }) => {
      return apiRequest("POST", "/api/pomodoro/sessions", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pomodoro/sessions"] });
      toast({
        title: "Session completed!",
        description: mode === "focus" ? "Great focus! Time for a break." : "Break finished. Ready to focus?",
      });
    },
  });

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    
    if (isRunning && time > 0) {
      interval = setInterval(() => {
        setTime((t) => t - 1);
      }, 1000);
    } else if (time === 0) {
      const duration = mode === "focus" ? 25 : 5;
      saveMutation.mutate({ duration, type: mode });
      
      if (mode === "focus") {
        setMode("break");
        setTime(5 * 60);
      } else {
        setMode("focus");
        setTime(25 * 60);
      }
      setIsRunning(false);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRunning, time, mode]);

  const minutes = Math.floor(time / 60);
  const seconds = time % 60;
  const progress = mode === "focus" 
    ? ((25 * 60 - time) / (25 * 60)) * 100
    : ((5 * 60 - time) / (5 * 60)) * 100;

  const todaySessions = sessions.filter(s => {
    const sessionDate = new Date(s.completedAt);
    const today = new Date();
    return sessionDate.toDateString() === today.toDateString() && s.type === "focus";
  });

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <Card>
        <CardHeader className="text-center">
          <CardTitle>
            {mode === "focus" ? "Focus Time" : "Break Time"}
          </CardTitle>
          <CardDescription>
            {mode === "focus"
              ? "Stay focused for 25 minutes"
              : "Take a 5 minute break"}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex flex-col items-center justify-center py-8">
            <div className="relative">
              <svg className="transform -rotate-90 w-64 h-64">
                <circle
                  cx="128"
                  cy="128"
                  r="112"
                  stroke="currentColor"
                  strokeWidth="12"
                  fill="none"
                  className="text-muted"
                />
                <circle
                  cx="128"
                  cy="128"
                  r="112"
                  stroke="currentColor"
                  strokeWidth="12"
                  fill="none"
                  strokeDasharray={2 * Math.PI * 112}
                  strokeDashoffset={2 * Math.PI * 112 * (1 - progress / 100)}
                  className="text-primary transition-all duration-1000"
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-4xl font-semibold font-mono" data-testid="text-timer">
                  {String(minutes).padStart(2, "0")}:{String(seconds).padStart(2, "0")}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-center gap-4">
            <Button
              size="lg"
              onClick={() => setIsRunning(!isRunning)}
              data-testid="button-start-pause"
            >
              {isRunning ? (
                <>
                  <Pause className="h-5 w-5 mr-2" />
                  Pause
                </>
              ) : (
                <>
                  <Play className="h-5 w-5 mr-2" />
                  Start
                </>
              )}
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => {
                setIsRunning(false);
                setTime(mode === "focus" ? 25 * 60 : 5 * 60);
              }}
              data-testid="button-reset"
            >
              <RotateCcw className="h-5 w-5 mr-2" />
              Reset
            </Button>
          </div>

          <div className="text-center">
            <p className="text-sm text-muted-foreground">
              Sessions completed today: <span className="font-semibold">{todaySessions.length}</span>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function KaizenTracker() {
  const [dailyGoal, setDailyGoal] = useState("");
  const { toast } = useToast();

  const { data: goals = [] } = useQuery<KaizenGoal[]>({
    queryKey: ["/api/kaizen/goals"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: { description: string; date: Date; completed: boolean }) => {
      return apiRequest("POST", "/api/kaizen/goals", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/kaizen/goals"] });
      setDailyGoal("");
      toast({
        title: "Goal added",
        description: "Keep improving, one day at a time!",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, completed }: { id: string; completed: boolean }) => {
      return apiRequest("PATCH", `/api/kaizen/goals/${id}`, { completed });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/kaizen/goals"] });
    },
  });

  const handleAddGoal = () => {
    if (dailyGoal.trim()) {
      createMutation.mutate({
        description: dailyGoal,
        date: new Date(),
        completed: false,
      });
    }
  };

  const weekStart = startOfWeek(new Date());
  const weekEnd = endOfWeek(new Date());
  const weekDays = eachDayOfInterval({ start: weekStart, end: weekEnd });

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Daily Improvement Goal</CardTitle>
          <CardDescription>
            What will you improve 1% today?
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            placeholder="Today, I will improve..."
            value={dailyGoal}
            onChange={(e) => setDailyGoal(e.target.value)}
            className="min-h-24"
            data-testid="textarea-daily-goal"
          />
          <Button
            onClick={handleAddGoal}
            disabled={createMutation.isPending}
            data-testid="button-add-goal"
          >
            <Plus className="h-4 w-4 mr-2" />
            {createMutation.isPending ? "Adding..." : "Add Goal"}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Weekly Progress</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-2">
            {weekDays.map((day) => {
              const dayGoals = goals.filter(
                (g) => format(new Date(g.date), "yyyy-MM-dd") === format(day, "yyyy-MM-dd")
              );
              const hasGoal = dayGoals.length > 0;
              const isCompleted = dayGoals.some((g) => g.completed);

              return (
                <div key={day.toISOString()} className="text-center">
                  <div className="text-xs text-muted-foreground mb-2">
                    {format(day, "EEE")}
                  </div>
                  <div
                    className={`aspect-square rounded-lg border-2 flex items-center justify-center ${
                      isCompleted
                        ? "bg-primary border-primary text-primary-foreground"
                        : hasGoal
                        ? "border-primary"
                        : "border-muted"
                    }`}
                  >
                    {isCompleted && <Check className="h-5 w-5" />}
                  </div>
                  <div className="text-xs mt-1">{format(day, "d")}</div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recent Goals</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {goals.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-8">
              No goals yet. Start by adding your first daily goal!
            </p>
          ) : (
            goals.map((goal) => (
              <div
                key={goal.id}
                className="flex items-start gap-3 p-3 rounded-lg border"
              >
                <Checkbox
                  checked={goal.completed}
                  onCheckedChange={(checked) =>
                    updateMutation.mutate({
                      id: goal.id,
                      completed: checked as boolean,
                    })
                  }
                  className="mt-1"
                  data-testid={`checkbox-goal-${goal.id}`}
                />
                <div className="flex-1">
                  <p className={goal.completed ? "line-through text-muted-foreground" : ""}>
                    {goal.description}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {format(new Date(goal.date), "MMM d, yyyy")}
                  </p>
                </div>
              </div>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function EisenhowerMatrix() {
  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [selectedQuadrant, setSelectedQuadrant] = useState<string | null>(null);
  const { toast } = useToast();

  const { data: tasks = [] } = useQuery<EisenhowerTask[]>({
    queryKey: ["/api/eisenhower/tasks"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: { title: string; quadrant: string; completed: boolean; noteId: string | null }) => {
      return apiRequest("POST", "/api/eisenhower/tasks", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/eisenhower/tasks"] });
      setNewTaskTitle("");
      setSelectedQuadrant(null);
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, completed }: { id: string; completed: boolean }) => {
      return apiRequest("PATCH", `/api/eisenhower/tasks/${id}`, { completed });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/eisenhower/tasks"] });
    },
  });

  const quadrants = [
    {
      id: "urgent-important",
      title: "Urgent & Important",
      description: "Do First",
    },
    {
      id: "important",
      title: "Important, Not Urgent",
      description: "Schedule",
    },
    {
      id: "urgent",
      title: "Urgent, Not Important",
      description: "Delegate",
    },
    {
      id: "neither",
      title: "Neither",
      description: "Eliminate",
    },
  ];

  const getTasksForQuadrant = (quadrantId: string) => {
    return tasks.filter((task) => task.quadrant === quadrantId);
  };

  const handleAddTask = (quadrantId: string) => {
    if (newTaskTitle.trim()) {
      createMutation.mutate({
        title: newTaskTitle,
        quadrant: quadrantId,
        completed: false,
        noteId: null,
      });
    }
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {quadrants.map((quadrant) => (
          <Card key={quadrant.id} data-testid={`card-quadrant-${quadrant.id}`}>
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <CardTitle className="text-lg">{quadrant.title}</CardTitle>
                  <CardDescription>{quadrant.description}</CardDescription>
                </div>
                <Badge variant="outline">{getTasksForQuadrant(quadrant.id).length}</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-2">
              {getTasksForQuadrant(quadrant.id).map((task) => (
                <div
                  key={task.id}
                  className="flex items-center gap-2 p-2 rounded border hover-elevate"
                >
                  <Checkbox
                    checked={task.completed}
                    onCheckedChange={(checked) =>
                      updateMutation.mutate({
                        id: task.id,
                        completed: checked as boolean,
                      })
                    }
                    data-testid={`checkbox-task-${task.id}`}
                  />
                  <span className={task.completed ? "line-through text-muted-foreground text-sm" : "text-sm"}>
                    {task.title}
                  </span>
                </div>
              ))}

              {selectedQuadrant === quadrant.id ? (
                <div className="flex gap-2 mt-2">
                  <Input
                    placeholder="Task title..."
                    value={newTaskTitle}
                    onChange={(e) => setNewTaskTitle(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        handleAddTask(quadrant.id);
                      } else if (e.key === "Escape") {
                        setSelectedQuadrant(null);
                        setNewTaskTitle("");
                      }
                    }}
                    autoFocus
                    className="flex-1"
                  />
                  <Button
                    size="sm"
                    onClick={() => handleAddTask(quadrant.id)}
                    disabled={createMutation.isPending}
                  >
                    Add
                  </Button>
                </div>
              ) : (
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full mt-2"
                  onClick={() => setSelectedQuadrant(quadrant.id)}
                  data-testid={`button-add-task-${quadrant.id}`}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Task
                </Button>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
