import { useState } from "react";
import { ChevronLeft, ChevronRight, Plus } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  format,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  isSameMonth,
  isSameDay,
  isToday,
  addMonths,
  subMonths,
} from "date-fns";
import { Link } from "wouter";
import type { Note } from "@shared/schema";

export default function Calendar() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);

  const { data: notes = [] } = useQuery<Note[]>({
    queryKey: ["/api/notes"],
  });

  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

  // Pad the calendar to start on Sunday
  const startDay = monthStart.getDay();
  const paddedDays = Array(startDay).fill(null).concat(daysInMonth);

  const getNotesForDate = (date: Date) => {
    return notes.filter((note) =>
      isSameDay(new Date(note.createdAt), date) ||
      isSameDay(new Date(note.updatedAt), date)
    );
  };

  const selectedDateNotes = selectedDate ? getNotesForDate(selectedDate) : [];

  return (
    <div className="flex flex-col h-full">
      <div className="flex-none border-b bg-background px-6 py-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-semibold">Calendar</h1>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setCurrentDate(subMonths(currentDate, 1))}
                data-testid="button-prev-month"
              >
                <ChevronLeft className="h-5 w-5" />
              </Button>
              <div className="min-w-40 text-center">
                <span className="text-lg font-medium">
                  {format(currentDate, "MMMM yyyy")}
                </span>
              </div>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setCurrentDate(addMonths(currentDate, 1))}
                data-testid="button-next-month"
              >
                <ChevronRight className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-auto">
        <div className="max-w-7xl mx-auto p-6">
          <div className="grid grid-cols-7 gap-2">
            {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
              <div
                key={day}
                className="text-center text-sm font-medium text-muted-foreground py-2"
              >
                {day}
              </div>
            ))}

            {paddedDays.map((day, index) => {
              if (!day) {
                return <div key={`empty-${index}`} className="aspect-square" />;
              }

              const dayNotes = getNotesForDate(day);
              const hasNotes = dayNotes.length > 0;
              const isCurrentMonth = isSameMonth(day, currentDate);
              const isTodayDate = isToday(day);

              return (
                <button
                  key={day.toISOString()}
                  onClick={() => setSelectedDate(day)}
                  className={`aspect-square p-2 rounded-md border transition-all hover-elevate ${
                    isCurrentMonth
                      ? "bg-card"
                      : "bg-muted/30 text-muted-foreground"
                  } ${isTodayDate ? "border-primary" : ""}`}
                  data-testid={`button-day-${format(day, "yyyy-MM-dd")}`}
                >
                  <div className="flex flex-col h-full">
                    <span
                      className={`text-sm ${
                        isTodayDate ? "font-semibold text-primary" : ""
                      }`}
                    >
                      {format(day, "d")}
                    </span>
                    {hasNotes && (
                      <div className="flex-1 flex items-end justify-center">
                        <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                      </div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <Dialog open={selectedDate !== null} onOpenChange={() => setSelectedDate(null)}>
        <DialogContent className="max-w-md" data-testid="dialog-day-notes">
          <DialogHeader>
            <DialogTitle>
              {selectedDate && format(selectedDate, "MMMM d, yyyy")}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            {selectedDateNotes.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-sm text-muted-foreground mb-4">
                  No notes for this day
                </p>
                <Link href="/note/new">
                  <Button size="sm" data-testid="button-create-note-from-calendar">
                    <Plus className="h-4 w-4 mr-2" />
                    Create Note
                  </Button>
                </Link>
              </div>
            ) : (
              <>
                {selectedDateNotes.map((note) => (
                  <Link key={note.id} href={`/note/${note.id}`}>
                    <Card className="hover-elevate cursor-pointer">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-base">{note.title}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex gap-1 flex-wrap">
                          {note.tags.map((tag) => (
                            <Badge key={tag} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
                <Link href="/note/new">
                  <Button className="w-full" variant="outline" size="sm">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Note
                  </Button>
                </Link>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
