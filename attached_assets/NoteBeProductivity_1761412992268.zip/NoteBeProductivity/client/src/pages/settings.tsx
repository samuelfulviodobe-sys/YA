import { Download, FileText, FileCode, FileImage } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { useTheme } from "@/components/theme-provider";
import { ThemeToggle } from "@/components/theme-toggle";

export default function Settings() {
  const { theme } = useTheme();

  const handleExport = (format: "txt" | "pdf" | "markdown") => {
    // Will be implemented in integration phase
    console.log(`Exporting as ${format}`);
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex-none border-b bg-background px-6 py-4">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-2xl font-semibold">Settings</h1>
        </div>
      </div>

      <div className="flex-1 overflow-auto">
        <div className="max-w-4xl mx-auto p-6 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Appearance</CardTitle>
              <CardDescription>
                Customize the look and feel of the application
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Theme</Label>
                  <p className="text-sm text-muted-foreground">
                    Current theme: {theme === "dark" ? "Dark" : "Light"}
                  </p>
                </div>
                <ThemeToggle />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Export Notes</CardTitle>
              <CardDescription>
                Download all your notes in different formats
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button
                variant="outline"
                className="w-full justify-start"
                onClick={() => handleExport("txt")}
                data-testid="button-export-txt"
              >
                <FileText className="h-4 w-4 mr-2" />
                Export as Text (.txt)
              </Button>
              <Button
                variant="outline"
                className="w-full justify-start"
                onClick={() => handleExport("pdf")}
                data-testid="button-export-pdf"
              >
                <FileImage className="h-4 w-4 mr-2" />
                Export as PDF (.pdf)
              </Button>
              <Button
                variant="outline"
                className="w-full justify-start"
                onClick={() => handleExport("markdown")}
                data-testid="button-export-markdown"
              >
                <FileCode className="h-4 w-4 mr-2" />
                Export as Markdown (.md)
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>About Note Be</CardTitle>
              <CardDescription>
                Productivity and organization made simple
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <p className="text-sm">
                Note Be combines intelligent notes, calendar, and proven productivity
                techniques like Pomodoro, Kaizen, and Eisenhower Matrix to help you
                stay focused and continuously improve.
              </p>
              <p className="text-sm text-muted-foreground">
                Version 1.0.0 - All data is stored locally for complete privacy.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
