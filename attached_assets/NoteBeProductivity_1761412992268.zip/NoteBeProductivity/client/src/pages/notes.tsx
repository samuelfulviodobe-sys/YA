import { useState } from "react";
import { Link } from "wouter";
import { Search, Plus, Star, Calendar as CalendarIcon, Tag } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import type { Note } from "@shared/schema";

export default function Notes() {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterTag, setFilterTag] = useState<string>("all");
  const [showFavorites, setShowFavorites] = useState(false);

  const { data: notes = [], isLoading } = useQuery<Note[]>({
    queryKey: ["/api/notes"],
  });

  const allTags = Array.from(
    new Set(notes.flatMap((note) => note.tags))
  );

  const filteredNotes = notes.filter((note) => {
    const matchesSearch =
      note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      note.content.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesTag = filterTag === "all" || note.tags.includes(filterTag);
    const matchesFavorite = !showFavorites || note.isFavorite;
    return matchesSearch && matchesTag && matchesFavorite;
  });

  return (
    <div className="flex flex-col h-full">
      <div className="flex-none border-b bg-background px-6 py-4">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-2xl font-semibold mb-4">Notes</h1>
          
          <div className="flex flex-col md:flex-row gap-4 items-start md:items-center">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search notes..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="input-search-notes"
              />
            </div>

            <div className="flex gap-2 flex-wrap">
              <Select value={filterTag} onValueChange={setFilterTag}>
                <SelectTrigger className="w-40" data-testid="select-filter-tag">
                  <Tag className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="All tags" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All tags</SelectItem>
                  {allTags.map((tag) => (
                    <SelectItem key={tag} value={tag}>
                      {tag}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Button
                variant={showFavorites ? "default" : "outline"}
                size="default"
                onClick={() => setShowFavorites(!showFavorites)}
                data-testid="button-filter-favorites"
              >
                <Star className="h-4 w-4 mr-2" />
                Favorites
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-auto">
        <div className="max-w-7xl mx-auto p-6">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <Card key={i}>
                  <CardHeader className="pb-3">
                    <Skeleton className="h-6 w-3/4" />
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-5/6" />
                    <div className="flex gap-1">
                      <Skeleton className="h-5 w-16" />
                      <Skeleton className="h-5 w-20" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : filteredNotes.length === 0 ? (
            <div className="flex flex-col items-center justify-center min-h-96 text-center">
              <div className="w-24 h-24 rounded-full bg-muted flex items-center justify-center mb-4">
                <Search className="h-12 w-12 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-medium mb-2">No notes found</h3>
              <p className="text-sm text-muted-foreground mb-6">
                {searchQuery || filterTag !== "all" || showFavorites
                  ? "Try adjusting your filters"
                  : "Create your first note to get started"}
              </p>
              <Link href="/note/new">
                <Button data-testid="button-create-first-note">
                  <Plus className="h-4 w-4 mr-2" />
                  Create Note
                </Button>
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredNotes.map((note) => (
                <Link key={note.id} href={`/note/${note.id}`}>
                  <Card
                    className="hover-elevate active-elevate-2 cursor-pointer transition-all duration-200"
                    data-testid={`card-note-${note.id}`}
                  >
                    <CardHeader className="flex flex-row items-start justify-between gap-2 space-y-0 pb-3">
                      <h3 className="font-medium text-lg line-clamp-2">
                        {note.title}
                      </h3>
                      {note.isFavorite && (
                        <Star className="h-4 w-4 fill-primary text-primary flex-shrink-0" />
                      )}
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <p className="text-sm text-muted-foreground line-clamp-3">
                        {note.content}
                      </p>
                      
                      {note.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1">
                          {note.tags.map((tag) => (
                            <Badge
                              key={tag}
                              variant="secondary"
                              className="text-xs"
                            >
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      )}

                      <div className="flex items-center text-xs text-muted-foreground pt-2">
                        <CalendarIcon className="h-3 w-3 mr-1" />
                        {format(new Date(note.updatedAt), "MMM d, yyyy")}
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>

      <Link href="/note/new">
        <Button
          size="icon"
          className="fixed bottom-6 right-6 h-14 w-14 rounded-full shadow-lg"
          data-testid="button-fab-new-note"
        >
          <Plus className="h-6 w-6" />
        </Button>
      </Link>
    </div>
  );
}
