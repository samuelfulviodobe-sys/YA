# Note Be - Productivity & Notes Application

## Overview
Note Be is a comprehensive productivity and organization application that combines intelligent note-taking with proven productivity methods. The application helps users structure their time and track personal progress through a beautiful, minimalist interface.

**Purpose:** Provide an all-in-one productivity solution combining notes, calendar, Pomodoro timer, Kaizen method, and Eisenhower Matrix for focus and continuous improvement.

**Current State:** MVP in development - Frontend components complete, backend implementation in progress.

**Last Updated:** October 25, 2025

## Recent Changes
- **Oct 25, 2025:** 
  - Created complete data schema for notes, pomodoro sessions, kaizen goals, and eisenhower tasks
  - Built all frontend React components with exceptional visual quality
  - Implemented sidebar navigation with Notes, Calendar, Productivity, and Settings sections
  - Created Notes page with search, filtering, and favorites
  - Built Note editor with tags, favorites, and auto-save UI
  - Developed Calendar with monthly grid view and day detail modal
  - Implemented Productivity page with tabs for Pomodoro timer, Kaizen tracker, and Eisenhower Matrix
  - Added Settings page with theme toggle and export options
  - Configured dark/light theme support with ThemeProvider

## Core Features
1. **Notes Management:** Create, edit, delete notes with tags, favorites, search, and filtering
2. **Calendar Integration:** Monthly view showing notes by date with quick creation
3. **Pomodoro Timer:** 25min focus + 5min break cycles with visual circular progress
4. **Kaizen Method:** Daily improvement goals with weekly progress tracking
5. **Eisenhower Matrix:** Task organization in 4 quadrants (urgent/important classification)
6. **Export Functionality:** TXT, PDF, and Markdown export options
7. **Theme Support:** Light and dark modes with smooth transitions
8. **Local Storage:** All data stored client-side for complete privacy

## Project Architecture

### Tech Stack
- **Frontend:** React, TypeScript, Wouter (routing), TailwindCSS, Shadcn UI
- **Backend:** Express.js, TypeScript
- **Storage:** In-memory (MemStorage) for MVP
- **State Management:** TanStack Query (React Query)
- **Styling:** Tailwind CSS with custom design system
- **Icons:** Lucide React
- **Date Handling:** date-fns

### Project Structure
```
client/
  src/
    components/
      theme-provider.tsx - Dark/light theme management
      theme-toggle.tsx - Theme switcher button
      app-sidebar.tsx - Main navigation sidebar
      ui/ - Shadcn UI components
    pages/
      notes.tsx - Notes list with search/filter
      note-editor.tsx - Create/edit note interface
      calendar.tsx - Monthly calendar view
      productivity.tsx - Pomodoro, Kaizen, Eisenhower tabs
      settings.tsx - App settings and export
      not-found.tsx - 404 page
    App.tsx - Main app with routing and layout
    index.css - Design system tokens and utilities
shared/
  schema.ts - TypeScript schemas and Zod validation
server/
  storage.ts - Storage interface and in-memory implementation
  routes.ts - API route handlers
```

### Data Models
- **Note:** id, title, content, tags[], isFavorite, createdAt, updatedAt
- **PomodoroSession:** id, duration, type (focus/break), completedAt
- **KaizenGoal:** id, description, date, completed
- **EisenhowerTask:** id, title, quadrant, completed, noteId (optional)

### Design System
- **Colors:** Blue primary (#2B7DE9), neutral grays, semantic colors
- **Typography:** Inter (primary), JetBrains Mono (monospace)
- **Spacing:** 2, 4, 6, 8, 12, 16 unit scale
- **Border Radius:** Small (3px), Medium (6px), Large (9px)
- **Animations:** Subtle 200-300ms transitions with ease-in-out
- **Component Philosophy:** Linear + Notion hybrid - minimal, focus-driven

### Key Patterns
- **Schema-First Development:** Define all schemas before implementation
- **Component Reusability:** Use Shadcn UI components consistently
- **Horizontal Batching:** Build complete layers (schema → frontend → backend → integration)
- **Design Guidelines:** Follow design_guidelines.md religiously for visual excellence
- **Elevation Interactions:** Use hover-elevate and active-elevate-2 utility classes
- **Theme-Aware:** All components support light/dark modes automatically

## User Preferences
- **Design Philosophy:** Minimalist, clean, professional interface with generous whitespace
- **Interaction Style:** Subtle hover/active states, smooth transitions
- **Layout Preference:** Sidebar navigation for desktop, responsive for mobile
- **Color Scheme:** Support both light and dark modes
- **Data Privacy:** Local storage only, no external accounts required

## Development Workflow
1. **Development:** npm run dev (runs Express + Vite on same port)
2. **Testing:** Use run_test tool for end-to-end validation
3. **Deployment:** Use suggest_deploy when ready

## API Routes (To Be Implemented)
- GET /api/notes - List all notes with optional filters
- POST /api/notes - Create new note
- GET /api/notes/:id - Get specific note
- PATCH /api/notes/:id - Update note
- DELETE /api/notes/:id - Delete note
- POST /api/pomodoro/sessions - Record completed session
- GET /api/pomodoro/sessions - Get session history
- GET /api/kaizen/goals - Get kaizen goals
- POST /api/kaizen/goals - Create kaizen goal
- PATCH /api/kaizen/goals/:id - Update goal completion
- GET /api/eisenhower/tasks - Get all tasks
- POST /api/eisenhower/tasks - Create task
- PATCH /api/eisenhower/tasks/:id - Update task
- DELETE /api/eisenhower/tasks/:id - Delete task
- GET /api/export/:format - Export notes (txt/pdf/markdown)

## Next Steps
1. Implement backend storage interface and API routes
2. Connect frontend to backend with React Query
3. Add loading and error states
4. Test core user journeys
5. Polish and optimize
