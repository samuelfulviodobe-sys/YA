# Note Be - Design Guidelines

## Design Approach

**Design System Foundation: Linear + Notion Hybrid**
This productivity application draws from Linear's minimal, focus-driven interface combined with Notion's flexible content organization. The design prioritizes clarity, speed, and unobtrusive functionality that supports daily productivity workflows.

**Core Principles:**
- Clarity over decoration: Every element serves a functional purpose
- Breathing room: Generous whitespace prevents cognitive overload
- Instant recognition: Consistent patterns across all productivity modules
- Respectful interactions: Subtle feedback without disrupting focus

---

## Typography System

**Font Stack:**
- Primary: Inter (400, 500, 600) via Google Fonts CDN
- Monospace: JetBrains Mono (400) for timestamps and data

**Hierarchy:**
- Page Titles: text-2xl font-semibold (32px)
- Section Headers: text-xl font-medium (24px)
- Card Titles: text-lg font-medium (20px)
- Body Text: text-base font-normal (16px)
- Labels/Meta: text-sm font-medium (14px)
- Timestamps/Captions: text-xs font-normal (12px)

**Line Heights:**
- Headings: leading-tight (1.25)
- Body text: leading-relaxed (1.625)
- Compact lists: leading-normal (1.5)

---

## Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 6, 8, 12, 16
- Micro spacing: p-2, gap-2 (buttons, chips)
- Standard spacing: p-4, gap-4, mb-6 (cards, sections)
- Large spacing: p-8, py-12, gap-8 (page sections)
- Extra large: py-16 (major section separation)

**Container Strategy:**
- App shell: max-w-7xl mx-auto px-4
- Content columns: max-w-4xl for reading areas
- Sidebar navigation: w-64 (desktop), full-width drawer (mobile)
- Modal dialogs: max-w-2xl

**Grid Systems:**
- Note cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4
- Calendar: 7-column grid for days
- Eisenhower Matrix: grid-cols-1 md:grid-cols-2 gap-4
- Kaizen progress: Single column with horizontal progress bars

---

## Component Library

### Navigation Architecture

**Top Navigation Bar:**
- Fixed header with backdrop blur effect
- Height: h-16
- Contains: App logo/name (left), search bar (center), profile/settings icon (right)
- Shadow: subtle bottom border, no heavy drop shadow

**Side Navigation (Desktop):**
- Persistent sidebar: w-64, fixed position
- Navigation items with icons (Heroicons) + labels
- Active state: subtle background treatment, left border accent
- Sections: Notes, Calendar, Productivity Tools, Settings
- Spacing: py-2 per item, px-4 container padding

**Bottom Navigation (Mobile):**
- Fixed bottom bar: h-16
- 4-5 primary navigation items with icons
- Active indicator: icon fills, minimal animation

### Note Components

**Note Card:**
- Rounded corners: rounded-lg
- Padding: p-4
- Border: 1px subtle border
- Hover state: slight elevation with shadow-md transition
- Structure: Title (text-lg font-medium), tag chips (inline), preview text (text-sm, line-clamp-3), timestamp (text-xs, bottom right)
- Action buttons: Edit/delete icons (top-right, visible on hover)

**Note Editor:**
- Clean textarea with min-h-96
- Auto-resize as content grows
- Title input: Large (text-2xl), borderless, placeholder styling
- Content area: text-base, leading-relaxed
- Tag selector: Multiselect chips below title
- Action bar: Fixed bottom with Save/Delete/Back buttons

**Tag Chips:**
- Size: px-3 py-1, rounded-full
- Text: text-xs font-medium
- Removable: Small × icon on the right
- Display inline-flex items-center gap-1

### Calendar Components

**Monthly Calendar Grid:**
- 7×5 or 7×6 grid based on month
- Day cells: aspect-square, rounded-md
- Current day: distinct border treatment
- Days with notes: small dot indicator below date
- Hover: Background change, pointer cursor
- Selected day: Filled background
- Adjacent month days: Reduced opacity (opacity-40)

**Day Detail View:**
- Slide-in panel or modal: max-w-md
- Header: Date (text-xl font-semibold)
- Note list: Compact cards with title + preview
- Quick add button: Floating (+) icon

### Productivity Tools

**Pomodoro Timer:**
- Circular progress indicator: Large, centered (w-64 h-64)
- Time display: text-4xl font-semibold inside circle
- Controls below: Start/Pause (primary button), Reset (secondary)
- Session counter: text-sm below timer
- Settings icon: Top-right for interval customization
- Spacing: Centered layout with py-12 container

**Kaizen Tracker:**
- Daily goal input: Large text area, placeholder "What will you improve 1% today?"
- Progress visualization: Horizontal bar chart or vertical timeline
- Weekly summary card: Grid showing 7 days with completion status
- Achievement badges: Small icons for streaks

**Eisenhower Matrix:**
- 2×2 grid layout: Equal quadrants with gap-4
- Quadrant structure:
  - Header: Icon + label (e.g., "Urgent & Important")
  - Task list: Compact items with checkbox + text
  - Add button: At bottom of each quadrant
- Each quadrant: p-4, rounded-lg, min-h-64
- Quick task input: Inline form appears on (+) click

### Form Elements

**Input Fields:**
- Standard height: h-12
- Padding: px-4
- Border: 1px border, rounded-md
- Focus state: Border accent, no outline ring
- Error state: Border in error color, helper text below

**Buttons:**
- Primary: px-6 py-3, rounded-md, font-medium
- Secondary: Same size, outline style with border
- Icon buttons: w-10 h-10, rounded-md, icon centered
- Floating action button (FAB): w-14 h-14, rounded-full, fixed bottom-right (bottom-6 right-6)
- Hover: opacity-90 transition
- Disabled: opacity-50, cursor-not-allowed

**Search Bar:**
- Width: w-full md:max-w-md
- Height: h-10
- Icon: Heroicons magnifying glass (left)
- Clear button: × icon (right, visible when input has value)
- Rounded: rounded-full
- Background: Subtle fill, not pure white/black

### Data Display

**Empty States:**
- Centered content: flex flex-col items-center justify-center
- Icon: Large (w-24 h-24), reduced opacity
- Message: text-lg, mb-4
- Action button: Primary CTA below message
- Min height: min-h-96

**Lists:**
- Item spacing: space-y-2
- Dividers: Optional subtle borders between items
- Hover: Background subtle change
- Checkbox: w-5 h-5, rounded-sm

**Modal/Dialog:**
- Backdrop: Overlay with backdrop-blur-sm
- Container: max-w-2xl, rounded-xl, p-6
- Header: text-xl font-semibold, mb-4
- Footer: Flex justify-end gap-3 for action buttons
- Close button: Absolute top-right

---

## Animations & Transitions

**Minimal Motion Philosophy:**
- Use sparingly, only for feedback and orientation
- Duration: 200ms for micro-interactions, 300ms for page transitions
- Easing: ease-in-out for smooth feel

**Approved Animations:**
- Button hover: opacity change (transition-opacity duration-200)
- Card hover: shadow elevation (transition-shadow duration-200)
- Modal enter/exit: Scale from 95% to 100% with fade
- List item add/remove: Slide + fade
- FAB appearance: Scale from 0 with slight bounce
- Page transitions: Fade between routes (duration-300)

**Forbidden:**
- Continuous looping animations
- Parallax scrolling effects
- Complex keyframe animations
- Decorative motion without purpose

---

## Responsive Behavior

**Breakpoints:**
- Mobile: Base (< 768px)
- Tablet: md: (768px+)
- Desktop: lg: (1024px+)

**Adaptive Patterns:**
- Side navigation → Bottom navigation (mobile)
- 3-column note grid → 2-column (tablet) → 1-column (mobile)
- Eisenhower matrix: 2×2 grid → Stacked quadrants (mobile)
- Calendar: Monthly view always, but cells adapt in size
- Modal dialogs: Full-screen on mobile, centered on desktop

---

## Accessibility Standards

**Focus Management:**
- Visible focus rings on all interactive elements (ring-2 ring-offset-2)
- Logical tab order throughout application
- Skip to content link for keyboard users

**Content:**
- All icons paired with aria-labels
- Form inputs with proper label associations
- Error messages linked via aria-describedby
- Minimum touch target: 44×44px (w-11 h-11 minimum)

**Visual:**
- Text contrast: Meets WCAG AA standards minimum
- Icon-only buttons include tooltips
- Status indicators use both visual and text cues

---

## Images

This productivity application does not use hero images. It's a utility-focused tool where visual content is user-generated (note content, potentially uploaded images within notes). The interface prioritizes functional density over marketing aesthetics.

**Icon System:** Heroicons via CDN (outline style for navigation, solid for actions)