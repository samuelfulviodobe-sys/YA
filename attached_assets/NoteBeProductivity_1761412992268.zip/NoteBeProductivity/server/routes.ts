import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import {
  insertNoteSchema,
  insertPomodoroSessionSchema,
  insertKaizenGoalSchema,
  insertEisenhowerTaskSchema,
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Notes routes
  app.get("/api/notes", async (req, res) => {
    try {
      const { search, tag, favorite } = req.query;
      const filters = {
        search: search as string | undefined,
        tag: tag as string | undefined,
        favorite: favorite === "true" ? true : favorite === "false" ? false : undefined,
      };
      const notes = await storage.getNotes(filters);
      res.json(notes);
    } catch (error) {
      console.error("Error getting notes:", error);
      res.status(500).json({ error: "Failed to fetch notes" });
    }
  });

  app.get("/api/notes/:id", async (req, res) => {
    try {
      const note = await storage.getNote(req.params.id);
      if (!note) {
        return res.status(404).json({ error: "Note not found" });
      }
      res.json(note);
    } catch (error) {
      console.error("Error getting note:", error);
      res.status(500).json({ error: "Failed to fetch note" });
    }
  });

  app.post("/api/notes", async (req, res) => {
    try {
      const validatedData = insertNoteSchema.parse(req.body);
      const note = await storage.createNote(validatedData);
      res.status(201).json(note);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Error creating note:", error);
      res.status(500).json({ error: "Failed to create note" });
    }
  });

  app.patch("/api/notes/:id", async (req, res) => {
    try {
      const validatedData = insertNoteSchema.partial().parse(req.body);
      const note = await storage.updateNote(req.params.id, validatedData);
      if (!note) {
        return res.status(404).json({ error: "Note not found" });
      }
      res.json(note);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Error updating note:", error);
      res.status(500).json({ error: "Failed to update note" });
    }
  });

  app.delete("/api/notes/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteNote(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Note not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting note:", error);
      res.status(500).json({ error: "Failed to delete note" });
    }
  });

  // Pomodoro sessions routes
  app.get("/api/pomodoro/sessions", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const sessions = await storage.getPomodoroSessions(limit);
      res.json(sessions);
    } catch (error) {
      console.error("Error getting pomodoro sessions:", error);
      res.status(500).json({ error: "Failed to fetch sessions" });
    }
  });

  app.post("/api/pomodoro/sessions", async (req, res) => {
    try {
      const validatedData = insertPomodoroSessionSchema.parse(req.body);
      const session = await storage.createPomodoroSession(validatedData);
      res.status(201).json(session);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Error creating pomodoro session:", error);
      res.status(500).json({ error: "Failed to create session" });
    }
  });

  // Kaizen goals routes
  app.get("/api/kaizen/goals", async (req, res) => {
    try {
      const { startDate, endDate } = req.query;
      const goals = await storage.getKaizenGoals(
        startDate ? new Date(startDate as string) : undefined,
        endDate ? new Date(endDate as string) : undefined
      );
      res.json(goals);
    } catch (error) {
      console.error("Error getting kaizen goals:", error);
      res.status(500).json({ error: "Failed to fetch goals" });
    }
  });

  app.post("/api/kaizen/goals", async (req, res) => {
    try {
      const validatedData = insertKaizenGoalSchema.parse(req.body);
      const goal = await storage.createKaizenGoal(validatedData);
      res.status(201).json(goal);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Error creating kaizen goal:", error);
      res.status(500).json({ error: "Failed to create goal" });
    }
  });

  app.patch("/api/kaizen/goals/:id", async (req, res) => {
    try {
      const { completed } = req.body;
      if (typeof completed !== "boolean") {
        return res.status(400).json({ error: "completed must be a boolean" });
      }
      const goal = await storage.updateKaizenGoal(req.params.id, completed);
      if (!goal) {
        return res.status(404).json({ error: "Goal not found" });
      }
      res.json(goal);
    } catch (error) {
      console.error("Error updating kaizen goal:", error);
      res.status(500).json({ error: "Failed to update goal" });
    }
  });

  // Eisenhower tasks routes
  app.get("/api/eisenhower/tasks", async (req, res) => {
    try {
      const tasks = await storage.getEisenhowerTasks();
      res.json(tasks);
    } catch (error) {
      console.error("Error getting eisenhower tasks:", error);
      res.status(500).json({ error: "Failed to fetch tasks" });
    }
  });

  app.post("/api/eisenhower/tasks", async (req, res) => {
    try {
      const validatedData = insertEisenhowerTaskSchema.parse(req.body);
      const task = await storage.createEisenhowerTask(validatedData);
      res.status(201).json(task);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Error creating eisenhower task:", error);
      res.status(500).json({ error: "Failed to create task" });
    }
  });

  app.patch("/api/eisenhower/tasks/:id", async (req, res) => {
    try {
      const validatedData = insertEisenhowerTaskSchema.partial().parse(req.body);
      const task = await storage.updateEisenhowerTask(req.params.id, validatedData);
      if (!task) {
        return res.status(404).json({ error: "Task not found" });
      }
      res.json(task);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Error updating eisenhower task:", error);
      res.status(500).json({ error: "Failed to update task" });
    }
  });

  app.delete("/api/eisenhower/tasks/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteEisenhowerTask(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Task not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting eisenhower task:", error);
      res.status(500).json({ error: "Failed to delete task" });
    }
  });

  // Export route - basic implementation
  app.get("/api/export/:format", async (req, res) => {
    try {
      const { format } = req.params;
      const notes = await storage.getNotes();

      if (format === "txt") {
        const text = notes
          .map(
            (note) =>
              `${note.title}\n${"=".repeat(note.title.length)}\n${note.content}\nTags: ${note.tags.join(", ")}\nCreated: ${note.createdAt.toLocaleDateString()}\n\n`
          )
          .join("\n");
        res.setHeader("Content-Type", "text/plain");
        res.setHeader("Content-Disposition", `attachment; filename="notes.txt"`);
        res.send(text);
      } else if (format === "markdown") {
        const markdown = notes
          .map(
            (note) =>
              `# ${note.title}\n\n${note.content}\n\n**Tags:** ${note.tags.join(", ")}  \n**Created:** ${note.createdAt.toLocaleDateString()}\n\n---\n\n`
          )
          .join("");
        res.setHeader("Content-Type", "text/markdown");
        res.setHeader("Content-Disposition", `attachment; filename="notes.md"`);
        res.send(markdown);
      } else if (format === "pdf") {
        // PDF generation would require a library like pdfkit or puppeteer
        // For now, return a placeholder
        res.status(501).json({ error: "PDF export not yet implemented" });
      } else {
        res.status(400).json({ error: "Invalid format. Use txt, markdown, or pdf" });
      }
    } catch (error) {
      console.error("Error exporting notes:", error);
      res.status(500).json({ error: "Failed to export notes" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
