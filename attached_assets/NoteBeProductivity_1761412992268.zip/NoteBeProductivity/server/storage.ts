import {
  type Note,
  type InsertNote,
  type PomodoroSession,
  type InsertPomodoroSession,
  type KaizenGoal,
  type InsertKaizenGoal,
  type EisenhowerTask,
  type InsertEisenhowerTask,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Notes
  getNotes(filters?: { search?: string; tag?: string; favorite?: boolean }): Promise<Note[]>;
  getNote(id: string): Promise<Note | undefined>;
  createNote(note: InsertNote): Promise<Note>;
  updateNote(id: string, note: Partial<InsertNote>): Promise<Note | undefined>;
  deleteNote(id: string): Promise<boolean>;

  // Pomodoro Sessions
  getPomodoroSessions(limit?: number): Promise<PomodoroSession[]>;
  createPomodoroSession(session: InsertPomodoroSession): Promise<PomodoroSession>;

  // Kaizen Goals
  getKaizenGoals(startDate?: Date, endDate?: Date): Promise<KaizenGoal[]>;
  createKaizenGoal(goal: InsertKaizenGoal): Promise<KaizenGoal>;
  updateKaizenGoal(id: string, completed: boolean): Promise<KaizenGoal | undefined>;

  // Eisenhower Tasks
  getEisenhowerTasks(): Promise<EisenhowerTask[]>;
  createEisenhowerTask(task: InsertEisenhowerTask): Promise<EisenhowerTask>;
  updateEisenhowerTask(
    id: string,
    updates: Partial<InsertEisenhowerTask>
  ): Promise<EisenhowerTask | undefined>;
  deleteEisenhowerTask(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private notes: Map<string, Note>;
  private pomodoroSessions: Map<string, PomodoroSession>;
  private kaizenGoals: Map<string, KaizenGoal>;
  private eisenhowerTasks: Map<string, EisenhowerTask>;

  constructor() {
    this.notes = new Map();
    this.pomodoroSessions = new Map();
    this.kaizenGoals = new Map();
    this.eisenhowerTasks = new Map();

    // Add some initial mock data for demonstration
    this.seedData();
  }

  private seedData() {
    // Seed notes
    const note1: Note = {
      id: randomUUID(),
      title: "Project Planning",
      content: "Define the architecture and milestones for the upcoming quarter. Focus on scalability and maintainability.",
      tags: ["Work", "Planning"],
      isFavorite: true,
      createdAt: new Date("2025-10-20"),
      updatedAt: new Date("2025-10-20"),
    };
    const note2: Note = {
      id: randomUUID(),
      title: "Learning Goals",
      content: "Continue studying design patterns and system architecture. Practice implementing common patterns.",
      tags: ["Study", "Personal"],
      isFavorite: false,
      createdAt: new Date("2025-10-18"),
      updatedAt: new Date("2025-10-23"),
    };
    this.notes.set(note1.id, note1);
    this.notes.set(note2.id, note2);

    // Seed Kaizen goals
    const goal1: KaizenGoal = {
      id: randomUUID(),
      description: "Improve documentation quality",
      date: new Date(),
      completed: true,
    };
    const goal2: KaizenGoal = {
      id: randomUUID(),
      description: "Learn new design pattern",
      date: new Date(Date.now() - 86400000),
      completed: true,
    };
    this.kaizenGoals.set(goal1.id, goal1);
    this.kaizenGoals.set(goal2.id, goal2);

    // Seed Eisenhower tasks
    const task1: EisenhowerTask = {
      id: randomUUID(),
      title: "Client presentation",
      quadrant: "urgent-important",
      completed: false,
      noteId: null,
      createdAt: new Date(),
    };
    const task2: EisenhowerTask = {
      id: randomUUID(),
      title: "Strategic planning",
      quadrant: "important",
      completed: false,
      noteId: null,
      createdAt: new Date(),
    };
    const task3: EisenhowerTask = {
      id: randomUUID(),
      title: "Email responses",
      quadrant: "urgent",
      completed: true,
      noteId: null,
      createdAt: new Date(),
    };
    this.eisenhowerTasks.set(task1.id, task1);
    this.eisenhowerTasks.set(task2.id, task2);
    this.eisenhowerTasks.set(task3.id, task3);
  }

  // Notes
  async getNotes(filters?: {
    search?: string;
    tag?: string;
    favorite?: boolean;
  }): Promise<Note[]> {
    let notes = Array.from(this.notes.values());

    if (filters?.search) {
      const searchLower = filters.search.toLowerCase();
      notes = notes.filter(
        (note) =>
          note.title.toLowerCase().includes(searchLower) ||
          note.content.toLowerCase().includes(searchLower)
      );
    }

    if (filters?.tag) {
      notes = notes.filter((note) => note.tags.includes(filters.tag!));
    }

    if (filters?.favorite !== undefined) {
      notes = notes.filter((note) => note.isFavorite === filters.favorite);
    }

    return notes.sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime());
  }

  async getNote(id: string): Promise<Note | undefined> {
    return this.notes.get(id);
  }

  async createNote(insertNote: InsertNote): Promise<Note> {
    const id = randomUUID();
    const now = new Date();
    const note: Note = {
      id,
      ...insertNote,
      createdAt: now,
      updatedAt: now,
    };
    this.notes.set(id, note);
    return note;
  }

  async updateNote(
    id: string,
    updates: Partial<InsertNote>
  ): Promise<Note | undefined> {
    const note = this.notes.get(id);
    if (!note) return undefined;

    const updatedNote: Note = {
      ...note,
      ...updates,
      updatedAt: new Date(),
    };
    this.notes.set(id, updatedNote);
    return updatedNote;
  }

  async deleteNote(id: string): Promise<boolean> {
    return this.notes.delete(id);
  }

  // Pomodoro Sessions
  async getPomodoroSessions(limit = 100): Promise<PomodoroSession[]> {
    const sessions = Array.from(this.pomodoroSessions.values());
    return sessions
      .sort((a, b) => b.completedAt.getTime() - a.completedAt.getTime())
      .slice(0, limit);
  }

  async createPomodoroSession(
    insertSession: InsertPomodoroSession
  ): Promise<PomodoroSession> {
    const id = randomUUID();
    const session: PomodoroSession = {
      id,
      ...insertSession,
      completedAt: new Date(),
    };
    this.pomodoroSessions.set(id, session);
    return session;
  }

  // Kaizen Goals
  async getKaizenGoals(startDate?: Date, endDate?: Date): Promise<KaizenGoal[]> {
    let goals = Array.from(this.kaizenGoals.values());

    if (startDate) {
      goals = goals.filter((goal) => goal.date >= startDate);
    }

    if (endDate) {
      goals = goals.filter((goal) => goal.date <= endDate);
    }

    return goals.sort((a, b) => b.date.getTime() - a.date.getTime());
  }

  async createKaizenGoal(insertGoal: InsertKaizenGoal): Promise<KaizenGoal> {
    const id = randomUUID();
    const goal: KaizenGoal = {
      id,
      ...insertGoal,
    };
    this.kaizenGoals.set(id, goal);
    return goal;
  }

  async updateKaizenGoal(
    id: string,
    completed: boolean
  ): Promise<KaizenGoal | undefined> {
    const goal = this.kaizenGoals.get(id);
    if (!goal) return undefined;

    const updatedGoal: KaizenGoal = {
      ...goal,
      completed,
    };
    this.kaizenGoals.set(id, updatedGoal);
    return updatedGoal;
  }

  // Eisenhower Tasks
  async getEisenhowerTasks(): Promise<EisenhowerTask[]> {
    return Array.from(this.eisenhowerTasks.values()).sort(
      (a, b) => a.createdAt.getTime() - b.createdAt.getTime()
    );
  }

  async createEisenhowerTask(
    insertTask: InsertEisenhowerTask
  ): Promise<EisenhowerTask> {
    const id = randomUUID();
    const task: EisenhowerTask = {
      id,
      ...insertTask,
      createdAt: new Date(),
    };
    this.eisenhowerTasks.set(id, task);
    return task;
  }

  async updateEisenhowerTask(
    id: string,
    updates: Partial<InsertEisenhowerTask>
  ): Promise<EisenhowerTask | undefined> {
    const task = this.eisenhowerTasks.get(id);
    if (!task) return undefined;

    const updatedTask: EisenhowerTask = {
      ...task,
      ...updates,
    };
    this.eisenhowerTasks.set(id, updatedTask);
    return updatedTask;
  }

  async deleteEisenhowerTask(id: string): Promise<boolean> {
    return this.eisenhowerTasks.delete(id);
  }
}

export const storage = new MemStorage();
